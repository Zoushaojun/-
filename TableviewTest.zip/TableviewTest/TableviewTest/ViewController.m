//
//  ViewController.m
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import "ViewController.h"
#import "SJButtonView.h"
#import "SJConfigure.h"
#import "UIView+WHC_AutoLayout.h"
#import "SJCell.h"
#import "SJModel.h"
#import "NSArray+SJArray.h"


@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,SJButtonViewDelegate>


@property (nonatomic, strong) UITableView *myTableview;

@property (nonatomic ,strong) NSMutableArray *myDataSource;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"动态";
    self.view.backgroundColor = rgb(245, 245, 245);
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.navigationController.navigationBar.translucent = NO;
    
    
    //加载右边item控件
    [self addRightItem];
    
    //加载头部buttonView
    [self addButtonView];
    
    //加载tableview
    [self addTableview];
    
    //加载tableview所需数据
    [self loadTableviewData];
    
    
    // Do any additional setup after loading the view, typically from a nib.
}



- (void)addRightItem
{
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCompose  target:self action:@selector(selectRightAction:)];
    rightButton.tintColor = [UIColor whiteColor];
    [self.navigationItem setRightBarButtonItem:rightButton];
    
    
}



- (void)addButtonView
{
    NSArray *array = @[@"好友动态",@"热门",@"最新",@"我的"];
    
    SJButtonView *buttonView = [[SJButtonView alloc] initWithFrame:CGRectMake(0, 0, kScreenW, 170)
                                                         headImage:[UIImage imageNamed:@"home_image1"]
                                                       buttonArray:array];
    buttonView.delegate = self;
    [self.view addSubview:buttonView];
    
}



- (void)addTableview
{
    
    _myTableview = [[UITableView alloc] initWithFrame:CGRectMake(0, 170, kScreenW, kScreenH -215)
                                                style:UITableViewStylePlain];
    _myTableview.delegate = self;
    _myTableview.dataSource = self;
    [self.view addSubview:_myTableview];
    
    [_myTableview registerClass:[SJCell class]
         forCellReuseIdentifier:NSStringFromClass([SJCell class])];

    
    _myTableview.tableFooterView = [UIView new];
    
}


- (void)loadTableviewData
{
    
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"Dynamic" ofType:@"plist"];
    
    NSMutableArray *dataArray = [[NSMutableArray alloc] initWithContentsOfFile:plistPath];
    
    
    if (![NSArray ArrayIsNull:dataArray]) {
        
        _myDataSource = [[NSMutableArray alloc] init];
        
        [dataArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop){
            
            SJModel *model = [[SJModel alloc] init];
            model.headPhoto = [obj objectForKey:@"headPhoto"];
            model.userName = [obj objectForKey:@"userName"];
            model.sex = [obj objectForKey:@"sex"];
            model.addTime = [obj objectForKey:@"addTime"];
            model.content = [obj objectForKey:@"content"];
            model.photoArray = [obj objectForKey:@"photoArray"];
            
            [_myDataSource addObject:model];
            
        }];
        
        
    }
    
    NSLog(@"count=%lu",(unsigned long)_myDataSource.count);
    
}





#pragma mark -- UITableViewDelegate --

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
 
    return _myDataSource.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 1;
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return [SJCell whc_CellHeightForIndexPath:indexPath tableView:tableView];
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    SJCell * cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SJCell class])];
    
    cell.backgroundColor = [UIColor whiteColor];
    
    SJModel *model = [_myDataSource objectAtIndex:indexPath.section];
    
    [cell reloadData:model];
    
    
    return cell;
    
    
    
}


- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath

{
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    cell.preservesSuperviewLayoutMargins = NO;
    
}

#pragma mark - 创建表尾视图
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    
    static NSString *ID = @"FooterView";
    
    UITableViewHeaderFooterView *FooterView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:ID];
    
    
    FooterView.backgroundColor = [UIColor redColor];
    
    return FooterView;
    
    
}




- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    
    return @"";
    
}

#pragma mark - 设置表尾视图高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    
    return 10.0f;
    
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
}





#pragma mark -- RightItemClick --

- (void)selectRightAction:(id)sender
{

    
    
    
}

#pragma mark -- SJButtonViewDelegate --

-(void)selectedButtonTitle:(NSString *)title
{
    
    if ([title isEqualToString:@"好友动态"]) {
        NSLog(@"加载好友动态");
    }else if ([title isEqualToString:@"热门"])
    {
        NSLog(@"加载热门动态");
    }else if ([title isEqualToString:@"最新"])
    {
        NSLog(@"加载最新动态");
    }else if ([title isEqualToString:@"我的"])
    {
        NSLog(@"加载我的动态");
    }
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
