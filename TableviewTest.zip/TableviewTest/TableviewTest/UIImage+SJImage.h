//
//  UIImage+SJImage.h
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (SJImage)

/** 颜色转换成图片 */
+ (UIImage *)imageWithColor:(UIColor *)color;

/** 按比例缩放,size 是你要把图显示到 多大区域 CGSizeMake(300, 140) */
+ (UIImage *) imageCompressForSize:(UIImage *)sourceImage targetSize:(CGSize)size;

/** 指定宽度按比例缩放 */
+ (UIImage *) imageCompressForWidth:(UIImage *)sourceImage targetWidth:(CGFloat)defineWidth;
@end
