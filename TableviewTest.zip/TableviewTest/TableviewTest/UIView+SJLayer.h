//
//  UIView+SJLayer.h
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (SJLayer)

- (void)viewSetRadius:(CGFloat)Radius borderWidth:(CGFloat)borderWidth borerColor:(CGColorRef)borerColor;

@end
