//
//  UIView+SJLayer.m
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import "UIView+SJLayer.h"

@implementation UIView (SJLayer)

- (void)viewSetRadius:(CGFloat)Radius borderWidth:(CGFloat)borderWidth borerColor:(CGColorRef)borerColor
{
    self.layer.masksToBounds = YES;
    self.layer.cornerRadius = Radius;
    self.layer.borderWidth = borderWidth;
    self.layer.borderColor = borerColor;
    //    self.clipsToBounds = YES;
    
}

@end
