//
//  UILabel+SJLabel.m
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import "UILabel+SJLabel.h"

@implementation UILabel (SJLabel)

- (CGFloat)labelWithText:(NSString *)text
                  font:(UIFont *)font
{
    
    NSDictionary *attribute = @{NSFontAttributeName:font};
    CGSize size = [text boundingRectWithSize:CGSizeMake(200, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading | NSStringDrawingTruncatesLastVisibleLine  attributes:attribute context:nil].size;
    
    return size.width;
    
}

@end
