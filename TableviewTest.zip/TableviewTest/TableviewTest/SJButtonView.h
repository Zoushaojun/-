//
//  SJButtonView.h
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol SJButtonViewDelegate <NSObject>

/** 选中button的代理 */
- (void)selectedButtonTitle:(NSString *)title;

@end


@interface SJButtonView : UIView

/** 代理 */
@property (nonatomic ,assign) id<SJButtonViewDelegate>delegate;


/** 创建buttonview的位置和所需数组 */
-(instancetype)initWithFrame:(CGRect)frame headImage:(UIImage *)image buttonArray:(NSArray *)array;


@end
