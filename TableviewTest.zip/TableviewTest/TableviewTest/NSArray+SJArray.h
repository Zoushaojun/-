//
//  NSArray+SJArray.h
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (SJArray)

/** 判断数组不等于空不等于NUll */
+ (BOOL)ArrayIsNull:(NSArray *)array;

/** 判断可变数组不等于空不等于NUll */
+ (BOOL)nsMutableArrayIsNull:(NSMutableArray *)array;

@end
