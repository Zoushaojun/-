//
//  SJModel.m
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import "SJModel.h"

@implementation SJModel

@end
