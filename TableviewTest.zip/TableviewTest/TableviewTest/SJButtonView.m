//
//  SJButtonView.m
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#define ButtonViewHeight 40


#import "SJButtonView.h"
#import "SJConfigure.h"
#import "NSArray+SJArray.h"
#import "UIImage+SJImage.h"

@interface SJButtonView ()

/** 按钮数组 */
@property (nonatomic ,strong) NSArray *buttonArray;

@end

@implementation SJButtonView

-(instancetype)initWithFrame:(CGRect)frame headImage:(UIImage *)image buttonArray:(NSArray *)array
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];
        
        //头部图片
        UIImageView *headImage = [[UIImageView alloc] init];
        headImage.frame = CGRectMake(0, 0, kScreenW, 130);
//        headImage.contentMode = UIViewContentModeScaleAspectFit;
//        headImage.image = image;
        headImage.image = [UIImage imageCompressForSize:image targetSize:CGSizeMake(kScreenW, 130)];
        [self addSubview:headImage];
        
        
        
        if (![NSArray ArrayIsNull:array]) {
            
            for (int i = 0; i <array.count ; i++) {
                
                UIButton *button = [[UIButton alloc] init];
                button.frame = CGRectMake( i * (75+3), 130, 75, 40);
                [button setTag:100+i];
                [button setTitle:[array objectAtIndex:i] forState:UIControlStateNormal];
                [button.titleLabel setFont:[UIFont systemFontOfSize:13.0]];
                [button setTitleColor:rgb(50, 50, 50) forState:UIControlStateNormal];
                [button addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
                if (i == 0)
                {
                    [button setTitleColor:rgb(3, 162, 253) forState:UIControlStateNormal];
                    
                }
                
                [self addSubview:button];
                
                
                
                
                if (i != array.count -1) {
                    
                    UIImageView *line = [[UIImageView alloc] init];
                    line.frame = CGRectMake((i+1)* (75+1), 144, 1, 12);
                    line.backgroundColor = rgb(225, 225, 225);
                    [self addSubview:line];
                }
                
                
                
            }
            
        }
        
        UIImageView *line1 = [[UIImageView alloc] init];
        line1.frame = CGRectMake(0, 130, kScreenW, 1);
        line1.backgroundColor = rgb(225, 225, 225);
        [self addSubview:line1];
        
        
        UIImageView *line2 = [[UIImageView alloc] init];
        line2.frame = CGRectMake(0, self.frame.size.height - 1, kScreenW, 1);
        line2.backgroundColor = rgb(225, 225, 225);
        [self addSubview:line2];
        
        
        
    }
    
    
    return self;

}




- (void)clickButton:(UIButton *)sender
{
    
    
    if (_delegate && [_delegate respondsToSelector:@selector(selectedButtonTitle:)]) {
        [_delegate selectedButtonTitle:sender.currentTitle];
    }
    
    
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[UIButton class]]) {
            if (view.tag == sender.tag) {
                [(UIButton *)view setTitleColor:rgb(3, 162, 253) forState:UIControlStateNormal];
            }else
            {
                [(UIButton *)view setTitleColor:rgb(50, 50, 50) forState:UIControlStateNormal];
            }
        }
    }
    

    
}


@end
