//
//  SJCell.m
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import "SJCell.h"
#import "UIView+WHC_AutoLayout.h"
#import "SJConfigure.h"
#import "UIView+SJLayer.h"
#import "UILabel+SJLabel.h"
#import "NSArray+SJArray.h"
#import "UIImage+SJImage.h"


@interface SJCell ()

@property (nonatomic ,strong) UIImageView *headImage;

@property (nonatomic ,strong) UILabel *userName;

@property (nonatomic ,strong) UIImageView *sex;

@property (nonatomic ,strong) UILabel *time;

@property (nonatomic ,strong) UILabel *content;

@property (nonatomic ,strong) NSMutableArray *photoArray;
@end

@implementation SJCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        _photoArray = [[NSMutableArray alloc] init];
        _headImage = [UIImageView new];
        _userName = [UILabel new];
        _sex = [UIImageView new];
        _time = [UILabel new];
        _content = [UILabel new];
        
        _userName.font = [UIFont systemFontOfSize:15.0];
        _time.font = [UIFont systemFontOfSize:12.0];
        _content.font = [UIFont systemFontOfSize:13.0];
        
        _userName.textColor = rgb(30, 30, 30);
        _time.textColor = rgb(180, 180, 180);
        _content.textColor = rgb(50, 50, 50);
        
        [self.contentView addSubview:_time];
        [self.contentView addSubview:_userName];
        [self.contentView addSubview:_content];
        
        [self.contentView addSubview:_headImage];
        [self.contentView addSubview:_sex];
        
        //布局
        [self addAutoLayout];
        
        
    }
 
    return self;
    
}


- (void)addAutoLayout
{
    
//    NSDictionary *attribute = @{NSFontAttributeName:[UIFont systemFontOfSize:15.0]};
//    CGSize size = [@"这是我的字符串" boundingRectWithSize:CGSizeMake(200, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading | NSStringDrawingTruncatesLastVisibleLine  attributes:attribute context:nil].size;

    
    _headImage.whc_LeftSpace(10)
              .whc_TopSpace(10)
              .whc_Size(CGSizeMake(40, 40));
    
    _userName.whc_LeftSpaceToView(10,_headImage)
             .whc_TopSpace(20)
             .whc_widthAuto()
             .whc_Height(20);
    
    _sex.whc_LeftSpaceToView(5,_userName)
        .whc_TopSpace(22)
        .whc_Size(CGSizeMake(15, 15));
    
    _time.whc_RightSpace(5)
         .whc_TopSpace(20)
         .whc_Size(CGSizeMake(75, 15));
    
    _content.whc_LeftSpace(10)
            .whc_TopSpaceToView(20,_headImage)
            .whc_RightSpace(10)
            .whc_heightAuto();
    
    self.whc_CellBottomOffset = 25;
    
    
}


-(void)reloadData:(SJModel *)SJModel
{
    
    _headImage.image = nil;
    _userName.text = @"";
    _sex.image = nil;
    _time.text = @"";
    _content.text = @"";
    
    
    [_headImage viewSetRadius:20 borderWidth:0 borerColor:[[UIColor whiteColor] CGColor]];
    
    _headImage.image = [UIImage imageCompressForSize:[UIImage imageNamed:SJModel.headPhoto] targetSize:CGSizeMake(40, 40)];
    
    _userName.text = SJModel.userName;
    NSString *sexImage = [SJModel.sex isEqualToString:@"1"]?@"nanren":@"nvren";
    
    _sex.image = [UIImage imageNamed:sexImage];
    
    _time.text = SJModel.addTime;
    
    _content.text = SJModel.content;
    
    if (![NSMutableArray nsMutableArrayIsNull:_photoArray]) {
        
        [_photoArray removeAllObjects];
        [_photoArray addObjectsFromArray:SJModel.photoArray];
        
    }else
    {
        [_photoArray addObjectsFromArray:SJModel.photoArray];
    }
    
    self.whc_CellBottomView = _content;
    
    
    if (![NSArray ArrayIsNull:_photoArray]) {
        
        NSLog(@"_array=%@",_photoArray);
        //遍历创建图片
        for (int i = 0 ; i < _photoArray.count ; i++)
        {
                UIImageView *image = [[UIImageView alloc] init];
                [self.contentView addSubview:image];
                
                CGSize size = CGSizeMake(100, 100);
                
                if (iphone5x_4_0) {
                    
                    size = CGSizeMake(93, 93);
                }else if(iphone6_4_7)
                {
                    
                    size = CGSizeMake(111, 111);
                }else if (iphone6Plus_5_5)
                {
                    size = CGSizeMake(124, 124);
                    
                }
                
                image.whc_LeftSpace(10+ i * (size.width+10))
                .whc_TopSpaceToView(15,_content)
                .whc_Size(size);
                image.image = [UIImage imageCompressForSize:[UIImage imageNamed:_photoArray[i]] targetSize:size];
                
                self.whc_CellBottomView = image;
            
            
        }
        
    
    }
    
    
}



-(void)dealloc
{
    NSLog(@"000");
}

@end
