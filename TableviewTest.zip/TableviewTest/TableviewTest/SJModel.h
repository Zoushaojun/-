//
//  SJModel.h
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SJModel : NSObject

/** 头像 */
@property (nonatomic ,copy) NSString *headPhoto;
/** 用户名称 */
@property (nonatomic ,copy) NSString *userName;
/** 性别 */
@property (nonatomic ,copy) NSString *sex;
/** 发布时间 */
@property (nonatomic ,copy) NSString *addTime;
/** 内容 */
@property (nonatomic ,copy) NSString *content;
/** 图片数组 */
@property (nonatomic ,strong) NSArray *photoArray;

@end
