//
//  Utility.h
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface Utility : NSObject



/**
 *	保存obj数据到本地
 *
 *	@param	obj	数据
 *	@param	key	键
 */
+ (void)saveToDefaults:(id)obj forKey:(NSString*)key;


/**
 *	从本地删除某个数据
 *
 *	@param	obj	数据
 *	@param	key	键
 */
+ (BOOL)removeForArrayObj:(id)obj forKey:(NSString*)key;


/**
 *	保存obj的array到本地，如果已经存在会替换本地。
 *
 *	@param	obj	待保存的obj
 *	@param	key	保存的key
 */
+ (void)saveToArrayDefaults:(id)obj forKey:(NSString*)key;


/**
 *	读取本地数据
 *
 *	@param	key	键
 */
+ (id)defaultsForKey:(NSString*)key;

/**
 *	判断这个数组是不是为空。或者不是数组类型
 */
+ (BOOL)ArrayIsNull:(NSArray *)array;



@end
