//
//  NSArray+SJArray.m
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import "NSArray+SJArray.h"

@implementation NSArray (SJArray)


+ (BOOL)ArrayIsNull:(NSArray *)array
{

    if (![array isKindOfClass:[NSArray class]]) {
        return YES;
    }
    
    if (!array || [array isKindOfClass:[NSNull class]] || array.count == 0 ) {
        return YES;
    }else{
        return NO;
    }
    
}

+ (BOOL)nsMutableArrayIsNull:(NSMutableArray *)array
{
    
    if (![array isKindOfClass:[NSMutableArray class]]) {
        return YES;
    }
    
    if (!array || [array isKindOfClass:[NSNull class]] || array.count == 0 ) {
        return YES;
    }else{
        return NO;
    }
    
}


@end
