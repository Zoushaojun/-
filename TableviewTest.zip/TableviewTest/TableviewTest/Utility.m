//
//  Utility.m
//  TableviewTest
//
//  Created by 邹少军 on 16/8/29.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import "Utility.h"




@implementation Utility


+ (void)saveToDefaults:(id)obj forKey:(NSString *)key
{
    
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setValue:obj forKey:key];
    [defaults synchronize];
}


+ (BOOL)removeForArrayObj:(id)obj forKey:(NSString *)key
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSArray *array = [defaults valueForKey:key];
    
    NSMutableArray *marray = [NSMutableArray array];
    if (array) {
        [marray addObjectsFromArray:array];
        if ([marray containsObject:obj]) {
            [marray removeObject:obj];
        }
    }
    if (marray.count) {
        [defaults setValue:marray forKey:key];
    }else{
        [defaults removeObjectForKey:key];
    }
    [defaults synchronize];
    return marray.count;
    
    
}


+ (void)saveToArrayDefaults:(id)obj forKey:(NSString *)key
{
    
    [self saveToArrayDefaults:obj replace:obj forKey:key];
    
    
}


+ (void)saveToArrayDefaults:(id)obj replace:(id)oldobj forKey:(NSString*)key
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSArray *array = [defaults valueForKey:key];
    
    NSMutableArray *marray = [NSMutableArray array];
    if (!oldobj) {
        oldobj = obj;
    }
    if (array) {
        [marray addObjectsFromArray:array];
        if ([marray containsObject:oldobj]) {
            [marray replaceObjectAtIndex:[marray indexOfObject:oldobj] withObject:obj];
        }else{
            [marray addObject:obj];
        }
    }else{
        [marray addObject:obj];
    }
    [defaults setValue:marray forKey:key];
    [defaults synchronize];
}


+ (id)defaultsForKey:(NSString*)key
{
    return [[NSUserDefaults standardUserDefaults] valueForKey:key];
}



@end
